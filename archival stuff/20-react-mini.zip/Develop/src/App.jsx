import './App.css';
import BucketList from './components/BucketList';

function App() {
  return (
    <div className="bucket-app">
      <BucketList />
    </div>
  );
}

export default App;
