DROP DATABASE IF EXISTS traveller_db;
CREATE DATABASE traveller_db;
