# JAnTE
JAnTE for "Just Another Text Editor" - textus emendator
