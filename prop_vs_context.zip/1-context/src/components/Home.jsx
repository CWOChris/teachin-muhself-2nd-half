import Section from './Section'

function Home() {

  return (
    <div style={{ border: '5px solid yellow', padding:"10px"}}>
      <h1>HOME</h1>
      <Section />
    </div>
  )
}

export default Home
