import MainBody from './MainBody'

function SubSection() {

    return (
      <div style={{border: '5px solid red', padding:"10px"}}>
        <h1>Other Section</h1>
        <MainBody />
      </div>
    )
  }
  
  export default SubSection
  