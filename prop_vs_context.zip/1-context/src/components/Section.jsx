import SubSection from './SubSection'

function Section() {

    return (
      <div style={{ border: '5px solid blue', padding:"10px"}}>
        <h1>Section</h1>
        <SubSection />
      </div>
    )
  }
  
  export default Section
  