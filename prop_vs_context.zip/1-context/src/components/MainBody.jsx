import Count from './Count'

function MainBody() {

    return (
      <div style={{border: '5px solid purple',  padding:"10px"}}>
        <h1>Count</h1>
        <Count />
      </div>
    )
  }
  
  export default MainBody
  